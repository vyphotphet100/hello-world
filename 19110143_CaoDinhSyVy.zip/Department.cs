using System;
using System.Collections.Generic;

namespace CSharpProject {
    public class Department {
        private String sName;
        private Employee eHeadOfDept;
        private List<Employee> lEmployees;

        // properties
        public String Name {
            get { return this.sName; }
            set { this.sName = value; }
        }

        public Employee HeadOfDept {
            get { return this.eHeadOfDept; }
            set { this.eHeadOfDept = value; }
        }

        public List<Employee> Employees {
            get { return this.lEmployees; }
            set { this.lEmployees = value; }
        }

        // Constructor
        public Department() {
            this.lEmployees = new List<Employee>();
        }

        public Department(String name) {
            this.sName = name;
        }

        public Department(String name, Employee headOfDept) {
            this.sName = name;
            this.eHeadOfDept = headOfDept;
        }

        // Input 
        public void Input(String name, Employee headOfDept, List<Employee> employees) {
            this.sName = name;
            this.eHeadOfDept = headOfDept;
            this.lEmployees = employees;
        }

        //Output 
        public void Output() {
            Console.WriteLine($"Department name: {0}", this.sName);
            Console.WriteLine($"Department manager: {0}", this.eHeadOfDept.Name);
            Console.WriteLine($"List of employees: ");
            for (int i=0; i<this.lEmployees.Count; i++) 
                Console.WriteLine(this.lEmployees[i].Name);
        }

        // Methods
        public void ComputeSalary() {
            for (int i=0; i<this.lEmployees.Count; i++)
                this.lEmployees[i].ComputeSalary();
        }

        public Employee EmployeeHavingLargestNumOfWorkDay() {
            int tmp = -1;
            for (int i=0; i<this.lEmployees.Count; i++) {
                if (tmp < this.lEmployees[i].NumOfWorkDay)
                    tmp = this.lEmployees[i].NumOfWorkDay;
            }

            for (int i=0; i<this.lEmployees.Count; i++) 
                if (this.lEmployees[i].NumOfWorkDay == tmp)
                    return this.lEmployees[i];
            
            return null;
        }

        public void SortingEmployeeBySalary() {
            for (int i = 0; i<this.lEmployees.Count - 1; i++) {
                for (int j=i+1; j<this.lEmployees.Count; j++) {
                    if (this.lEmployees[i].Salary < this.lEmployees[j].Salary) {
                        Employee tmp = this.lEmployees[i];
                        this.lEmployees[i] = this.lEmployees[j];
                        this.lEmployees[j] = tmp;
                    }
                }
            }
        }

        public List<Employee> ListEmployeesHavingNumOfWorkDaySmallThan30() {
            List<Employee> res = new List<Employee>();
            for (int i=0; i<this.lEmployees.Count; i++) {
                if (this.lEmployees[i].NumOfWorkDay < 30)
                    res.Add(this.lEmployees[i]);
            }

            return res;
        }

        public int TotalSalary() {
            int res = 0;
            for (int i=0; i<this.lEmployees.Count; i++) {
                res += this.Employees[i].Salary;
            }

            return res;
        }

    }
}