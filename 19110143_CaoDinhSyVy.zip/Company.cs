using System;
using System.Collections.Generic;

namespace CSharpProject {
    public class Company { 
        private String sName;
        private List<Department> lDepts; 
        private Employee eManager;
        private List<Employee> lDeputyManagers;

        // properties
        public String Name {
            get { return this.sName; }
            set { this.sName = value; }
        }

        public List<Department> Departments {
            get { return this.lDepts; }
            set { this.lDepts = value; }
        }

        public Employee Manager {
            get { return this.eManager; }
            set { this.eManager = value; }
        }

        public List<Employee> DeputyManagers {
            get { return this.lDeputyManagers; }
            set { this.lDeputyManagers = value; }
        }

        //Constructor
        public Company() {
            this.lDepts = new List<Department>();
            this.lDeputyManagers = new List<Employee>();
        }

        public Company(String name) {
            this.sName = name;
        }

        public Company(String name, Employee manager) {
            this.sName = name;
            this.eManager = manager;
        }

        // Input 
        public void Input(String name, List<Department> depts, Employee manager, List<Employee> deputyManagers) {
            this.sName = name;
            this.lDepts = depts;
            this.eManager= manager;
            this.lDeputyManagers = deputyManagers;
        }

        // Output 
        public void Output() {
            Console.WriteLine($"Company name: {0}", this.sName);
            Console.WriteLine($"Company manager: {0}", this.eManager.Name);
            Console.WriteLine("List of department: ");
            for (int i=0; i<this.lDepts.Count; i++) 
                Console.WriteLine(this.lDepts[i].Name);
        }

        // Method
        public void ComputeSalary() {
            for (int i=0; i<this.lDepts.Count; i++) 
                this.lDepts[i].ComputeSalary();
        }

        public Employee EmployeeHavingLargestNumOfWorkDay() {
            int tmp = -1; 
            for (int i=0; i<this.lDepts.Count; i++) {
                int tmp2 = this.lDepts[i].EmployeeHavingLargestNumOfWorkDay().NumOfWorkDay;
                if (tmp < tmp2)
                    tmp = tmp2;
            }

            for (int i=0; i<this.lDepts.Count; i++) {
                Employee tmp2 = this.lDepts[i].EmployeeHavingLargestNumOfWorkDay();
                if (tmp == tmp2.NumOfWorkDay)
                    return tmp2;
            }

            return null;
        }

        public int TotalSalary() {
            int res = 0;
            for (int i=0; i<this.lDepts.Count; i++) {
                res += this.lDepts[i].TotalSalary();
            }

            return res;
        }

        public List<Employee> ListEmployeesHavingNumOfWorkDaySmallThan30() {
            List<Employee> res = new List<Employee>();

            for (int i=0; i<this.lDepts.Count; i++) {
                List<Employee> tmp = this.lDepts[i].ListEmployeesHavingNumOfWorkDaySmallThan30();
                for (int k=0; k<tmp.Count; i++) 
                    res.Add(tmp[i]);
            }

            return res;
        }
    }
}