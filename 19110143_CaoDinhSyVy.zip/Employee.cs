using System;
using System.Collections.Generic;

namespace CSharpProject {
    public class Employee {
        private String sName;
        private String sID;
        private int iSalaryPerDay;
        private int iNumOfWorkDay;
        private int iSalary;

        // properties
        public String Name {
            get { return this.sName; }
            set { this.sName = value; }
        }

        public String ID {
            get { return this.sID; }
            set { this.sID = value; }
        }

        public int SalaryPerDay {
            get { return this.iSalaryPerDay; }
            set { this.iSalaryPerDay = value; }
        }

        public int NumOfWorkDay {
            get { return this.iNumOfWorkDay; }
            set { this.iNumOfWorkDay = value; }
        }

        public int Salary {
            get { return this.iSalary; }
        }

        // Constructor
        public Employee() {

        }

        public Employee(String name, String id) {
            this.sName = name;
            this.sID = id;
        }

        // Input 
        public void Input(String name, String id, int salaryPerDay, int numOfWorkDay) {
            this.sName = name;
            this.sID = id;
            this.iSalaryPerDay = salaryPerDay;
            this.iNumOfWorkDay = numOfWorkDay;
        }

        // Output
        public void Output() {
            Console.WriteLine($"Name: {0}", this.sName);
            Console.WriteLine($"ID: {0}", this.sID);
            Console.WriteLine($"Salary per day: {0}", this.iSalaryPerDay);
            Console.WriteLine($"Number of work day: {0}", this.iNumOfWorkDay);
            Console.WriteLine($"Salary: {0}", this.iSalary);
        }

        // Methods
        public void ComputeSalary() {
            this.iSalary = this.iSalaryPerDay*30;
        }
    }
}